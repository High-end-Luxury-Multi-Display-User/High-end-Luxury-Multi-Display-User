#include "GpioService.hpp"

#include <android-base/logging.h>
#include <android/binder_manager.h>
#include <android/binder_process.h>

int main()
{
    ABinderProcess_setThreadPoolMaxThreadCount(0);
    std::shared_ptr<aidl::android::vendor::gpio::GpioService> gpio = ndk::SharedRefBase::make<aidl::android::vendor::gpio::GpioService>();

    const std::string instance = std::string() + aidl::android::vendor::gpio::GpioService::descriptor + "/default";
    binder_status_t status = AServiceManager_addService(gpio->asBinder().get(), instance.c_str());
    LOG(INFO) << "Registering service with name: " << instance;

    CHECK(status == STATUS_OK);
    if (status == STATUS_OK) {
        LOG(INFO) << "Service registered successfully.";
    } else {
        LOG(ERROR) << "Failed to register service. Status: " << status;
        return EXIT_FAILURE;
    }
    ABinderProcess_joinThreadPool();
    return EXIT_FAILURE;
}
