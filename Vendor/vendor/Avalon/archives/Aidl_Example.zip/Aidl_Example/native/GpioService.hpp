#pragma once

#include <aidl/android/vendor/gpio/BnGpioService.h>
#include "lib/gpiohal.h"

namespace aidl::android::vendor::gpio
{

    class GpioService : public BnGpioService
    {
    public:
        GpioService();
        ~GpioService(){}

    ::ndk::ScopedAStatus setGpioState(int32_t in_pin, bool in_value, bool *_aidl_return) override;
    ::ndk::ScopedAStatus getGpioState(int32_t in_pin, bool *_aidl_return) override;

    private:
          std::unique_ptr<GpioHal> gpioHal; 
    };

}
