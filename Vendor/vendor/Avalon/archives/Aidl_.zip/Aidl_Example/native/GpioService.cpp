#include "GpioService.hpp"



namespace aidl::android::vendor::gpio {

    GpioService::GpioService() : gpioHal(std::make_unique<GpioHal>()) {}

    ::ndk::ScopedAStatus GpioService::setGpioState(int32_t in_pin, bool in_value, bool *_aidl_return)
    {
        gpioHal->exportGpio(in_pin);

        gpioHal->setGpioDirection(in_pin, "out");

        bool result = gpioHal->setGpioValue(in_pin, in_value);

        return ndk::ScopedAStatus::ok();
    }

    ::ndk::ScopedAStatus GpioService::getGpioState(int32_t in_pin, bool *_aidl_return)

    {
        int pinValue;
        gpioHal->exportGpio(in_pin);

        gpioHal->setGpioDirection(in_pin, "in");

        bool result = gpioHal->getGpioValue(in_pin, &pinValue);

        *_aidl_return=(pinValue!=0);

        return ndk::ScopedAStatus::ok();
    }


}


