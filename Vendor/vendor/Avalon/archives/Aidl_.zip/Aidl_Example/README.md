follow same structure that exist on /hardware 

i did it on vendor so /vendor/aidl/android/vendor/(name) 

- blue print exist inside aidl dir for aidl_interface


m android.vendor.gpio-update-api -j12
m android.vendor.gpio-V1-java
 m android.vendor.gpio-V1-cpp


VINTF is vendor stability and its like a validation that this interface are going between vendor and frame work so this will be tested using VTS vendor test suite Ensures the interface contract remains consistent across Android versions

it declares that the interface is stable enough to be used between Android framework and vendor components