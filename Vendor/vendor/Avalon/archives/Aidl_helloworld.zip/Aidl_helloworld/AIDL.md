## create native/src/impl dir 

## native/src/service


## to check if the VINTF manifest is loaded or not 

adb shell dmesg | grep (interface package)




## update the aidl api 

make android.vendor.test-update-api




## the service was not able to be registered because the missing VINTF even if i was adding it 








