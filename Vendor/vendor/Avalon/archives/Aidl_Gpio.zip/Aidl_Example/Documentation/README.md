follow same structure that exist on /hardware 

i did it on vendor so /vendor/aidl/android/vendor/(name) 

- blue print exist inside aidl dir for aidl_interface


m android.vendor.gpio-update-api -j12
m android.vendor.gpio-V1-java
 m android.vendor.gpio-V1-cpp


VINTF is vendor stability and its like a validation that this interface are going between vendor and frame work so this will be tested using VTS vendor test suite Ensures the interface contract remains consistent across Android versions

it declares that the interface is stable enough to be used between Android framework and vendor components


# Steps


## 1- Create interface as same dir structured used by android 

- create interfaces/gpio/android/vendor/gpio/IGpioService.aidl


## 2- fill the interface with actual implenetation and annotate it with VINTFStability


```cpp
package android.vendor.gpio;

@VintfStability
interface IGpioService {
	boolean setGpioState(int pin, boolean value);
	boolean getGpioState(int pin);
}

```


## 3- create the Android.bp for aidl_interface and generate the stubs 

``` c

aidl_interface{
    name: "android.vendor.gpio",
    srcs:["android/vendor/gpio/*.aidl"],
    stability: "vintf",
    backend: {
        ndk:{
            enabled:true,
        },
        cpp:{
            enabled:true,
        },
        java:{
            enabled:true,	
        }

    },
   vendor_available: true,  
}
```

## 4- notify the system that the interface has been modified and freeze the current modification to specific version

```bash 

make android.vendor.gpio-update-api

```


Compares the current AIDL interface definitions with the existing generated API files.

Updates the generated interface code if there are changes.

Ensures the API versioning and compatibility are maintained (sometimes it will check for backward compatibility or flag breaking changes).


```bash 

make android.vendor.gpio-freeze-api


```


versioning of aidl interface if you want to get back to this versions 


## 5- generate the stubs make android.vendor.gpio-V1-ndk android.vendor.gpio-V1-java



## check the generated stubs
![alt text](image-1.png) 





## 6- create native dir 



## 7- create the impl for the Interface and import the shared libarary to drive the led

touch GpioService.cpp GpioService.hpp

``` c
#include "GpioService.hpp"



namespace aidl::android::vendor::gpio {

    GpioService::GpioService() : gpioHal(std::make_unique<GpioHal>()) {}

    ::ndk::ScopedAStatus GpioService::setGpioState(int32_t in_pin, bool in_value, bool *_aidl_return)
    {
        gpioHal->exportGpio(in_pin);

        gpioHal->setGpioDirection(in_pin, "out");

        bool result = gpioHal->setGpioValue(in_pin, in_value);

        return ndk::ScopedAStatus::ok();
    }

    ::ndk::ScopedAStatus GpioService::getGpioState(int32_t in_pin, bool *_aidl_return)

    {
        int pinValue;
        gpioHal->exportGpio(in_pin);

        gpioHal->setGpioDirection(in_pin, "in");

        bool result = gpioHal->getGpioValue(in_pin, &pinValue);

        *_aidl_return=(pinValue!=0);

        return ndk::ScopedAStatus::ok();
    }

}


```

## implement BaseNative because this is the serverside and it will be a native service 

``` c

#pragma once

#include <aidl/android/vendor/gpio/BnGpioService.h>
#include "lib/gpiohal.h"

namespace aidl::android::vendor::gpio
{

    class GpioService : public BnGpioService
    {
    public:
        GpioService();
        ~GpioService(){}

    ::ndk::ScopedAStatus setGpioState(int32_t in_pin, bool in_value, bool *_aidl_return) override;
    ::ndk::ScopedAStatus getGpioState(int32_t in_pin, bool *_aidl_return) override;

    private:
          std::unique_ptr<GpioHal> gpioHal; 
    };

}



```


## create the init.rc to start after boot on class hal 

``` sh
on early-boot
    chown system system /sys/class/gpio/*
    chmod 777 /sys/class/gpio/*

service gpio_service /vendor/bin/hw/gpio_service
	class hal
	user root
	group root
	

on boot
	start gpio_service


```

## create the se Policies 

``` sh





```








